<?php
require_once 'config.php';
require_once 'auth.php';

$erro = '';

// Processar login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $usuario = $_POST['usuario'] ?? '';
    $senha = $_POST['senha'] ?? '';
    
    if (login($usuario, $senha)) {
        header('Location: dashboard.php');
        exit;
    } else {
        $erro = 'Usuário ou senha incorretos.';
    }
}

// Se já estiver logado, redirecionar para dashboard
if (isLogado()) {
    header('Location: dashboard.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmaAura - Login</title>
    <link rel="stylesheet" href="style.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>
<body class="body-login">
    <div id="tela-login" class="tela">
        <header class="header-login">
            <div class="logo">
                <img src="Captura_de_tela_2025-10-13_123538-removebg-preview.png" alt="Logo FarmaAura" class="logo-imagem">
                <div>
                    <h1 class="tituloLogo">FarmaAura</h1>
                    <p>Gestão Farmacêutica Inteligente</p>
                </div>
            </div>
        </header>

        <main class="login-container">
            <div class="login-card">
                <div class="login-header">
                    <div class="login-icon-wrapper">
                        <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/></svg>
                    </div>
                    <h2>Bem-vindo de volta</h2>
                    <p>Acesse sua conta para continuar</p>
                </div>
                
                <form method="POST" action="">
                    <div class="form-group">
                        <label for="usuario">Usuário</label>
                        <input type="text" id="usuario" name="usuario" placeholder="Digite seu usuário" required>
                    </div>
                    <div class="form-group">
                        <label for="senha">Senha</label>
                        <input type="password" id="senha" name="senha" placeholder="Digite sua senha" required>
                    </div>
                    
                    <?php if ($erro): ?>
                        <div class="erro-login" style="display: block;"><?php echo e($erro); ?></div>
                    <?php endif; ?>
                    
                    <button type="submit" name="login" class="btn btn-secondary btn-full-width" style="margin-top: 1rem;">Entrar no Sistema</button>
                </form>
            </div>
        </main>
    </div>
</body>
</html>