<?php
// Garantir que os arquivos de configuração e autenticação sejam carregados
// (Assumindo que este arquivo está em 'pages/' e os outros na raiz)
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../auth.php';
requireLogin(); // Garante que o usuário está logado

$busca = $_GET['busca'] ?? '';
$db = getDB(); // Pega a conexão com o banco de dados

// SQL para buscar produtos, juntando o nome do fornecedor
$sql = "SELECT p.*, f.nome AS fornecedor_nome 
        FROM produtos p 
        LEFT JOIN fornecedores f ON p.fornecedor_id = f.id 
        WHERE 1=1";
$params = [];

if ($busca) {
    // Busca por nome do produto, código ou nome do fornecedor
    $sql .= " AND (p.nome LIKE ? OR p.codigo LIKE ? OR f.nome LIKE ?)";
    $params[] = "%$busca%";
    $params[] = "%$busca%";
    $params[] = "%$busca%";
}

$sql .= " ORDER BY p.nome ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$produtos = $stmt->fetchAll();
?>

<div class="page-header">
    <h2>Gerenciar Produtos</h2>
    <a href="api/produto.php?action=form" class="btn btn-primary"> Adicionar</a>
</div>

<div class="busca-container">
    <form method="GET" action="">
        <input type="hidden" name="p" value="produtos"> <input type="text" name="busca" placeholder="Buscar por nome, código ou fornecedor..." value="<?php echo e($busca); ?>" id="busca-produto">
    </form>
</div>

<div class="grid-container">
    <?php foreach ($produtos as $p): ?>
        <div class="card">
            <div class="card-header">
                <div>
                    <h3><?php echo e($p['nome']); ?></h3>
                    <p>Código: <?php echo e($p['codigo']); ?></p>
                </div>
                <div class="card-actions">
                    <a href="api/produto.php?action=form&id=<?php echo $p['id']; ?>" class="btn btn-outline btn-secondary">✏️</a>
                    <a href="api/produto.php?action=delete&id=<?php echo $p['id']; ?>" class="btn btn-outline btn-danger" onclick="return confirm('Tem certeza que deseja excluir este produto? A ação será registrada no histórico.')">🗑️</a>
                </div>
            </div>
            
            <div class="info-grid">
                <div class="info-box">
                    <span>Fornecedor</span>
                    <?php echo e($p['fornecedor_nome'] ?? 'N/A'); ?>
                </div>
                <div class="info-box">
                    <span>Estoque</span>
                    <?php echo e($p['quantidade']); ?> unidades
                </div>
                <div class="info-box">
                    <span>Preço</span>
                    <?php echo formatMoeda($p['preco']); ?>
                </div>
            </div>
            
            <?php if ($p['descricao']): ?>
                <div class="obs-box">
                    <span>Descrição</span>
                    <?php echo nl2br(e($p['descricao'])); // nl2br para quebrar linhas ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    
    <?php if (empty($produtos)): ?>
        <p style="grid-column: 1/-1; text-align: center; padding: 2rem;">Nenhum produto encontrado.</p>
    <?php endif; ?>
</div>

<script>
// Busca em tempo real
document.getElementById('busca-produto').addEventListener('input', function(e) {
    const form = this.closest('form');
    clearTimeout(this.searchTimeout);
    this.searchTimeout = setTimeout(() => form.submit(), 500); // Delay de 500ms
});
</script>