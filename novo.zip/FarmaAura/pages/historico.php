<?php
$db = getDB();
$stmt = $db->query("SELECT * FROM historico_produtos ORDER BY data_hora DESC LIMIT 100");
$historico = $stmt->fetchAll();
?>

<div class="page-header">
    <h2>Histórico de Alterações de Produtos</h2>
</div>

<div class="tabela-container">
    <table class="tabela">
        <thead>
            <tr>
                <th>ID Log</th>
                <th>Data/Hora</th>
                <th>Produto</th>
                <th>Ação</th>
                <th>Responsável</th>
                <th>Detalhes</th>
            </tr>
        </thead>
        <tbody>
            <?php if (!empty($historico)): ?>
                <?php foreach ($historico as $log): ?>
                    <tr>
                        <td><?php echo $log['id']; ?></td>
                        <td><?php echo formatData($log['data_hora']); ?></td>
                        <td><?php echo e($log['produto_codigo'] . ' / ' . $log['produto_nome']); ?></td>
                        <td>
                            <span class="badge <?php echo strtolower($log['acao']); ?>">
                                <?php echo e($log['acao']); ?>
                            </span>
                        </td>
                        <td><?php echo e($log['usuario_responsavel']); ?></td>
                        <td><?php echo e($log['detalhes']); ?></td>
                    </tr>
                <?php endforeach; ?>
            <?php else: ?>
                <tr>
                    <td colspan="6" style="text-align:center;">Nenhum registro encontrado.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>