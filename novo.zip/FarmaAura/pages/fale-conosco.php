<?php
$mensagem = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['enviar_contato'])) {
    $mensagem = 'Mensagem enviada com sucesso! (Demonstração)';
}
?>

<div class="page-header centered">
    <h2>Fale Conosco</h2>
</div>

<?php if ($mensagem): ?>
    <div style="background-color: #dcfce7; color: #166534; border: 1px solid #a7f3d0; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; text-align: center;">
        <?php echo e($mensagem); ?>
    </div>
<?php endif; ?>

<div class="form-contato">
    <p style="margin-bottom: 2rem; text-align: center;">
        Tem alguma dúvida, sugestão ou precisa de suporte? Preencha o formulário abaixo.
    </p>
    
    <form method="POST" action="">
        <div class="form-group">
            <label for="contato-nome">Nome</label>
            <input type="text" id="contato-nome" name="nome" placeholder="Seu nome completo" required>
        </div>
        
        <div class="form-group">
            <label for="contato-email">Email</label>
            <input type="email" id="contato-email" name="email" placeholder="seu.email@exemplo.com" required>
        </div>
        
        <div class="form-group">
            <label for="contato-assunto">Assunto</label>
            <input type="text" id="contato-assunto" name="assunto" placeholder="Sobre o que você quer falar?" required>
        </div>
        
        <div class="form-group">
            <label for="contato-mensagem">Mensagem</label>
            <textarea id="contato-mensagem" name="mensagem" rows="6" placeholder="Digite sua mensagem aqui..." required></textarea>
        </div>
        
        <button type="submit" name="enviar_contato" class="btn-enviar">Enviar Mensagem</button>
    </form>
</div>