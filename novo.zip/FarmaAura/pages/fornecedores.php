<?php
$busca = $_GET['busca'] ?? '';
$db = getDB();

// Buscar fornecedores com filtro
$sql = "SELECT * FROM fornecedores WHERE 1=1";
$params = [];

if ($busca) {
    $sql .= " AND (nome LIKE ? OR cnpj LIKE ?)";
    $params[] = "%$busca%";
    $params[] = "%$busca%";
}

$sql .= " ORDER BY nome ASC";
$stmt = $db->prepare($sql);
$stmt->execute($params);
$fornecedores = $stmt->fetchAll();
?>

<div class="page-header">
    <h2>Gerenciar Fornecedores</h2>
    <a href="api/fornecedor.php?action=form" class="btn btn-primary"> Adicionar</a>
</div>

<div class="busca-container">
    <form method="GET" action="">
        <input type="hidden" name="p" value="fornecedores">
        <input type="text" name="busca" placeholder="Buscar por nome ou CNPJ..." value="<?php echo e($busca); ?>" id="busca-fornecedor">
    </form>
</div>

<div class="grid-container">
    <?php foreach ($fornecedores as $f): ?>
        <div class="card">
            <div class="card-header">
                <div>
                    <h3><?php echo e($f['nome']); ?></h3>
                    <p>CNPJ: <?php echo e($f['cnpj']); ?></p>
                </div>
                <div class="card-actions">
                    <a href="api/fornecedor.php?action=form&id=<?php echo $f['id']; ?>" class="btn btn-outline btn-secondary">✏️</a>
                    <a href="api/fornecedor.php?action=delete&id=<?php echo $f['id']; ?>" class="btn btn-outline btn-danger" onclick="return confirm('Tem certeza que deseja excluir este fornecedor?')">🗑️</a>
                </div>
            </div>
            <div class="info-grid">
                <div class="info-box">
                    <span>Endereço</span>
                    <?php echo e($f['endereco']); ?>
                </div>
                <div class="info-box">
                    <span>Contato</span>
                    <?php echo e($f['telefone']); ?><br>
                    <?php echo e($f['email']); ?>
                </div>
            </div>
            <?php if ($f['observacoes']): ?>
                <div class="obs-box">
                    <span>Observações</span>
                    <?php echo e($f['observacoes']); ?>
                </div>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>
    
    <?php if (empty($fornecedores)): ?>
        <p style="grid-column: 1/-1; text-align: center; padding: 2rem;">Nenhum fornecedor encontrado.</p>
    <?php endif; ?>
</div>

<script>
// Busca em tempo real
document.getElementById('busca-fornecedor').addEventListener('input', function(e) {
    const form = this.closest('form');
    clearTimeout(this.searchTimeout);
    this.searchTimeout = setTimeout(() => form.submit(), 500);
});
</script>