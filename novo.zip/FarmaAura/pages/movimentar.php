<?php
$db = getDB();
$usuario = getUsuarioLogado();

// Buscar produtos para o select
$produtos = $db->query("SELECT id, codigo, nome, quantidade FROM produtos ORDER BY nome")->fetchAll();

// Processar movimentação
$mensagem = '';
$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['movimentar'])) {
    $produto_id = intval($_POST['produto_id'] ?? 0);
    $tipo = $_POST['tipo'] ?? '';
    $quantidade = intval($_POST['quantidade'] ?? 0);
    $motivo = $_POST['motivo'] ?? '';
    
    if ($produto_id && $tipo && $quantidade > 0) {
        // Buscar produto atual
        $stmt = $db->prepare("SELECT * FROM produtos WHERE id = ?");
        $stmt->execute([$produto_id]);
        $produto = $stmt->fetch();
        
        if ($produto) {
            $quantidade_anterior = $produto['quantidade'];
            $quantidade_nova = $quantidade_anterior;
            
            if ($tipo === 'entrada') {
                $quantidade_nova += $quantidade;
                $acao_tipo = 'Entrada';
                $acao_texto = "+$quantidade un";
            } else {
                if ($quantidade_anterior >= $quantidade) {
                    $quantidade_nova -= $quantidade;
                    $acao_tipo = 'Saida';
                    $acao_texto = "-$quantidade un";
                } else {
                    $erro = "Quantidade insuficiente em estoque! Disponível: $quantidade_anterior";
                }
            }
            
            if (!$erro) {
                // Atualizar estoque
                $stmt = $db->prepare("UPDATE produtos SET quantidade = ? WHERE id = ?");
                $stmt->execute([$quantidade_nova, $produto_id]);
                
                // Registrar no histórico
                $detalhes = "$acao_texto. Estoque: $quantidade_anterior -> $quantidade_nova. Motivo: $motivo";
                $stmt = $db->prepare("INSERT INTO historico_produtos (produto_id, produto_codigo, produto_nome, acao, detalhes, usuario_responsavel) VALUES (?, ?, ?, ?, ?, ?)");
                $stmt->execute([$produto_id, $produto['codigo'], $produto['nome'], $acao_tipo, $detalhes, $usuario['nome']]);
                
                $mensagem = "Movimentação realizada com sucesso!";
            }
        } else {
            $erro = "Produto não encontrado.";
        }
    } else {
        $erro = "Preencha todos os campos obrigatórios.";
    }
}
?>

<div class="page-header">
    <h2>Movimentar Estoque</h2>
</div>

<?php if ($mensagem): ?>
    <div style="background-color: #dcfce7; color: #166534; border: 1px solid #a7f3d0; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; text-align: center;">
        <?php echo e($mensagem); ?>
    </div>
<?php endif; ?>

<?php if ($erro): ?>
    <div style="background-color: #fee2e2; color: #991b1b; border: 1px solid #fecaca; padding: 1rem; border-radius: 8px; margin-bottom: 2rem; text-align: center;">
        <?php echo e($erro); ?>
    </div>
<?php endif; ?>

<div class="form-container">
    <p style="margin-bottom: 2rem; text-align: center; color: #64748b;">
        Registre entradas e saídas de produtos do estoque.
    </p>
    
    <form method="POST" action="">
        <div class="form-grid">
            <div class="form-group full-width">
                <label for="produto_id">Produto *</label>
                <select id="produto_id" name="produto_id" required onchange="atualizarEstoque()">
                    <option value="">Selecione um produto</option>
                    <?php foreach ($produtos as $p): ?>
                        <option value="<?php echo $p['id']; ?>" data-estoque="<?php echo $p['quantidade']; ?>">
                            <?php echo e($p['codigo'] . ' - ' . $p['nome'] . ' (Estoque: ' . $p['quantidade'] . ')'); ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <small id="estoque-atual" style="display: block; margin-top: 0.5rem; color: #64748b;"></small>
            </div>
            
            <div class="form-group">
                <label for="tipo">Tipo de Movimentação *</label>
                <select id="tipo" name="tipo" required>
                    <option value="">Selecione</option>
                    <option value="entrada">Entrada</option>
                    <option value="saida">Saída</option>
                </select>
            </div>
            
            <div class="form-group">
                <label for="quantidade">Quantidade *</label>
                <input type="number" id="quantidade" name="quantidade" min="1" placeholder="Digite a quantidade" required>
            </div>
            
            <div class="form-group full-width">
                <label for="motivo">Motivo/Observação *</label>
                <textarea id="motivo" name="motivo" rows="3" placeholder="Ex: Compra de fornecedor, venda, devolução, ajuste de inventário..." required></textarea>
            </div>
        </div>
        
        <div class="form-actions">
            <button type="submit" name="movimentar" class="btn-salvar">
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align: middle;"><polyline points="20 6 9 17 4 12"></polyline></svg>
                Confirmar Movimentação
            </button>
        </div>
    </form>
</div>

<script>
function atualizarEstoque() {
    const select = document.getElementById('produto_id');
    const estoqueAtual = document.getElementById('estoque-atual');
    const option = select.options[select.selectedIndex];
    
    if (option.value) {
        const estoque = option.getAttribute('data-estoque');
        estoqueAtual.textContent = `Estoque atual: ${estoque} unidades`;
        estoqueAtual.style.fontWeight = '600';
    } else {
        estoqueAtual.textContent = '';
    }
}
</script>