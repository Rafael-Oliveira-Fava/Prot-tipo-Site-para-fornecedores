<div class="page-header">
    <h2>Página Inicial</h2>
</div>

<div class="stats-bar">
    <div class="stat-item">
        <div class="stat-icon">🛒</div>
        <div>
            <h4>Movimentações</h4>
            <p><?php echo number_format($totalMovimentacoes, 0, ',', '.'); ?></p>
        </div>
    </div>
    <div class="stat-item">
        <div class="stat-icon">📦</div>
        <div>
            <h4>Produtos em Estoque</h4>
            <p><?php echo number_format($totalUnidades, 0, ',', '.'); ?></p>
        </div>
    </div>
    <div class="stat-item">
        <div class="stat-icon">🏆</div>
        <div>
            <h4>Fornecedores</h4>
            <p><?php echo number_format($totalFornecedores, 0, ',', '.'); ?></p>
        </div>
    </div>
    <div class="stat-item">
        <div class="stat-icon">💡</div>
        <div>
            <h4>Produtos Cadastrados</h4>
            <p><?php echo number_format($totalProdutos, 0, ',', '.'); ?></p>
        </div>
    </div>
</div>