<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmaAura - Gestão Farmacêutica</title>
    
    <link rel="stylesheet" href="landing.css">
    
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&family=Playfair+Display:wght@700;800&display=swap" rel="stylesheet">
    
</head>
<body class="body-landing">

    <header class="landing-header">
        <a href="index.php" class="header-logo-container">
            <img src="Captura_de_tela_2025-10-13_123538-removebg-preview.png" alt="Logo FarmaAura" class="header-logo">
            <span>FarmaAura</span>
        </a>
        <nav class="header-nav">
            <a href="index.php">Página Inicial</a>
            <a href="login.php">Fale conosco</a>
            <a href="login.php" class="nav-login">Login
                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </a>
        </nav>
    </header>

    <main class="landing-main">
        <div class="landing-content">
            <h1>
                Transforme a gestão da sua empresa <span>com mais controle e segurança.</span>
            </h1>
            <p>
                Nossa plataforma unifica o gerenciamento de Produtos resultando em maior padronização, qualidade e total confiabilidade para sua operação.
            </p>
            
            <a href="login.php" class="btn btn-dark">Login</a>
        </div>
    </main>

    <footer class="landing-footer">
        <p class="copyright">FarmaAura © 2025</p>
        <p class="tagline">GESTÃO FARMACÊUTICA INTELIGENTE</p>
    </footer>

</body>
</html>