<?php
require_once '../config.php';
require_once '../auth.php';
requireLogin();

$db = getDB();
$action = $_GET['action'] ?? '';
$id = $_GET['id'] ?? null;
$usuario = getUsuarioLogado();

// DELETAR
if ($action === 'delete' && $id) {
    // Buscar produto antes de deletar para registrar no histórico
    $stmt = $db->prepare("SELECT * FROM produtos WHERE id = ?");
    $stmt->execute([$id]);
    $produto = $stmt->fetch();
    
    if ($produto) {
        // Registrar exclusão no histórico
        $stmt = $db->prepare("INSERT INTO historico_produtos (produto_id, produto_codigo, produto_nome, acao, detalhes, usuario_responsavel) VALUES (?, ?, ?, 'Exclusão', 'Produto removido do sistema.', ?)");
        $stmt->execute([$produto['id'], $produto['codigo'], $produto['nome'], $usuario['nome']]);
        
        // Deletar produto
        $stmt = $db->prepare("DELETE FROM produtos WHERE id = ?");
        $stmt->execute([$id]);
    }
    
    header('Location: ../dashboard.php?p=produtos');
    exit;
}

// FORMULÁRIO
if ($action === 'form') {
    $produto = null;
    if ($id) {
        $stmt = $db->prepare("SELECT * FROM produtos WHERE id = ?");
        $stmt->execute([$id]);
        $produto = $stmt->fetch();
    }
    
    // Buscar fornecedores para o select
    $fornecedores = $db->query("SELECT id, nome FROM fornecedores ORDER BY nome")->fetchAll();
    
    // SALVAR
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $dados = [
            'nome' => $_POST['nome'] ?? '',
            'codigo' => $_POST['codigo'] ?? '',
            'descricao' => $_POST['descricao'] ?? '',
            'quantidade' => intval($_POST['quantidade'] ?? 0),
            'preco' => floatval($_POST['preco'] ?? 0),
            'fornecedor_id' => intval($_POST['fornecedor_id'] ?? 0)
        ];
        
        if ($id) {
            // Atualizar - buscar dados originais
            $stmt = $db->prepare("SELECT * FROM produtos WHERE id = ?");
            $stmt->execute([$id]);
            $produtoOriginal = $stmt->fetch();
            
            // Registrar mudanças
            $detalhes = [];
            if ($produtoOriginal['nome'] !== $dados['nome']) {
                $detalhes[] = "Nome: '{$produtoOriginal['nome']}' -> '{$dados['nome']}'";
            }
            if ($produtoOriginal['quantidade'] != $dados['quantidade']) {
                $detalhes[] = "Estoque: {$produtoOriginal['quantidade']} -> {$dados['quantidade']}";
            }
            if ($produtoOriginal['preco'] != $dados['preco']) {
                $detalhes[] = "Preço: R$" . number_format($produtoOriginal['preco'], 2, ',', '.') . " -> R$" . number_format($dados['preco'], 2, ',', '.');
            }
            
            $detalhesTexto = !empty($detalhes) ? implode('; ', $detalhes) : 'Nenhuma alteração de dados.';
            
            // Atualizar produto
            $stmt = $db->prepare("UPDATE produtos SET nome=?, codigo=?, descricao=?, quantidade=?, preco=?, fornecedor_id=? WHERE id=?");
            $stmt->execute([$dados['nome'], $dados['codigo'], $dados['descricao'], $dados['quantidade'], $dados['preco'], $dados['fornecedor_id'], $id]);
            
            // Registrar no histórico
            $stmt = $db->prepare("INSERT INTO historico_produtos (produto_id, produto_codigo, produto_nome, acao, detalhes, usuario_responsavel) VALUES (?, ?, ?, 'Edição', ?, ?)");
            $stmt->execute([$id, $dados['codigo'], $dados['nome'], $detalhesTexto, $usuario['nome']]);
            
        } else {
            // Criar novo produto
            $stmt = $db->prepare("INSERT INTO produtos (nome, codigo, descricao, quantidade, preco, fornecedor_id) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$dados['nome'], $dados['codigo'], $dados['descricao'], $dados['quantidade'], $dados['preco'], $dados['fornecedor_id']]);
            
            $novoProdutoId = $db->lastInsertId();
            
            // Registrar criação no histórico
            $stmt = $db->prepare("INSERT INTO historico_produtos (produto_id, produto_codigo, produto_nome, acao, detalhes, usuario_responsavel) VALUES (?, ?, ?, 'Criação', 'Produto novo cadastrado.', ?)");
            $stmt->execute([$novoProdutoId, $dados['codigo'], $dados['nome'], $usuario['nome']]);
        }
        
        header('Location: ../dashboard.php?p=produtos');
        exit;
    }
    ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $id ? 'Editar' : 'Adicionar'; ?> Produto</title>
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&display=swap" rel="stylesheet">
        <style>
            body { background-color: var(--cor-fundo); padding: 2rem; }
            .form-container { max-width: 800px; margin: 0 auto; background: white; padding: 2rem; border-radius: 16px; border: 1px solid var(--cor-borda); }
            .form-grid { display: grid; gap: 1rem; }
            .form-actions { margin-top: 2rem; display: flex; justify-content: flex-end; gap: 1rem; }
        </style>
    </head>
    <body>
        <div class="form-container">
            <h2><?php echo $id ? 'Editar' : 'Adicionar'; ?> Produto</h2>
            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nome">Nome do Produto *</label>
                        <input type="text" id="nome" name="nome" value="<?php echo e($produto['nome'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="codigo">Código *</label>
                        <input type="text" id="codigo" name="codigo" value="<?php echo e($produto['codigo'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="quantidade">Quantidade *</label>
                        <input type="number" id="quantidade" name="quantidade" value="<?php echo e($produto['quantidade'] ?? 0); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="preco">Preço *</label>
                        <input type="number" id="preco" name="preco" step="0.01" value="<?php echo e($produto['preco'] ?? 0); ?>" required>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="descricao">Descrição</label>
                        <textarea id="descricao" name="descricao" rows="4"><?php echo e($produto['descricao'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="fornecedor_id">Fornecedor *</label>
                        <select id="fornecedor_id" name="fornecedor_id" required>
                            <option value="">Selecione um fornecedor</option>
                            <?php foreach ($fornecedores as $f): ?>
                                <option value="<?php echo $f['id']; ?>" <?php echo ($produto['fornecedor_id'] ?? '') == $f['id'] ? 'selected' : ''; ?>>
                                    <?php echo e($f['nome']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" onclick="history.back()" class="btn-cancelar">Cancelar</button>
                    <button type="submit" class="btn-salvar">Salvar</button>
                </div>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>