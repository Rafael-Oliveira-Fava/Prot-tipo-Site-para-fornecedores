<?php
require_once '../config.php';
require_once '../auth.php';
requireLogin();

$db = getDB();
$action = $_GET['action'] ?? '';
$id = $_GET['id'] ?? null;

// DELETAR
if ($action === 'delete' && $id) {
    $stmt = $db->prepare("DELETE FROM fornecedores WHERE id = ?");
    $stmt->execute([$id]);
    header('Location: ../dashboard.php?p=fornecedores');
    exit;
}

// FORMULÁRIO
if ($action === 'form') {
    $fornecedor = null;
    if ($id) {
        $stmt = $db->prepare("SELECT * FROM fornecedores WHERE id = ?");
        $stmt->execute([$id]);
        $fornecedor = $stmt->fetch();
    }
    
    // SALVAR
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $dados = [
            'nome' => $_POST['nome'] ?? '',
            'cnpj' => $_POST['cnpj'] ?? '',
            'endereco' => $_POST['endereco'] ?? '',
            'telefone' => $_POST['telefone'] ?? '',
            'email' => $_POST['email'] ?? '',
            'observacoes' => $_POST['observacoes'] ?? ''
        ];
        
        if ($id) {
            // Atualizar
            $stmt = $db->prepare("UPDATE fornecedores SET nome=?, cnpj=?, endereco=?, telefone=?, email=?, observacoes=? WHERE id=?");
            $stmt->execute([$dados['nome'], $dados['cnpj'], $dados['endereco'], $dados['telefone'], $dados['email'], $dados['observacoes'], $id]);
        } else {
            // Criar
            $stmt = $db->prepare("INSERT INTO fornecedores (nome, cnpj, endereco, telefone, email, observacoes) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt->execute([$dados['nome'], $dados['cnpj'], $dados['endereco'], $dados['telefone'], $dados['email'], $dados['observacoes']]);
        }
        
        header('Location: ../dashboard.php?p=fornecedores');
        exit;
    }
    ?>
    <!DOCTYPE html>
    <html lang="pt-BR">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title><?php echo $id ? 'Editar' : 'Adicionar'; ?> Fornecedor</title>
        <link rel="stylesheet" href="../style.css">
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&display=swap" rel="stylesheet">
        <style>
            body { background-color: var(--cor-fundo); padding: 2rem; }
            .form-container { max-width: 800px; margin: 0 auto; background: white; padding: 2rem; border-radius: 16px; border: 1px solid var(--cor-borda); }
            .form-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
            .form-group.full-width { grid-column: span 2; }
            .form-actions { margin-top: 2rem; display: flex; justify-content: flex-end; gap: 1rem; }
        </style>
    </head>
    <body>
        <div class="form-container">
            <h2><?php echo $id ? 'Editar' : 'Adicionar'; ?> Fornecedor</h2>
            <form method="POST" action="">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="nome">Nome da Empresa *</label>
                        <input type="text" id="nome" name="nome" value="<?php echo e($fornecedor['nome'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="cnpj">CNPJ *</label>
                        <input type="text" id="cnpj" name="cnpj" value="<?php echo e($fornecedor['cnpj'] ?? ''); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="endereco">Endereço</label>
                        <input type="text" id="endereco" name="endereco" value="<?php echo e($fornecedor['endereco'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="telefone">Telefone</label>
                        <input type="text" id="telefone" name="telefone" value="<?php echo e($fornecedor['telefone'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="email">Email</label>
                        <input type="email" id="email" name="email" value="<?php echo e($fornecedor['email'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group full-width">
                        <label for="observacoes">Observações</label>
                        <textarea id="observacoes" name="observacoes" rows="4"><?php echo e($fornecedor['observacoes'] ?? ''); ?></textarea>
                    </div>
                </div>
                
                <div class="form-actions">
                    <button type="button" onclick="history.back()" class="btn-cancelar">Cancelar</button>   
                    <button type="submit" class="btn-salvar">Salvar</button>
                </div>
            </form>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>