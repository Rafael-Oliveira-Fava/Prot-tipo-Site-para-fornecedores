<?php
require_once 'config.php';

// Iniciar a sessão se ainda não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Função de login
function login($usuario, $senha) {
    $db = getDB();
    $stmt = $db->prepare("SELECT * FROM fornecedores WHERE usuario = ?");
    $stmt->execute([$usuario]);
    $fornecedor = $stmt->fetch();
    
    // Verificar senha (usando comparação direta por simplicidade, mas use password_verify em produção)
    if ($fornecedor && $fornecedor['senha'] === $senha) {
        $_SESSION['usuario_logado'] = [
            'id' => $fornecedor['id'],
            'nome' => $fornecedor['nome'],
            'email' => $fornecedor['email']
        ];
        return true;
    }
    
    return false;
}

// Função de logout (REMOVIDO o header daqui, pois o logout.php já faz isso)
function logout() {
    unset($_SESSION['usuario_logado']);
    session_destroy();
}

// Verificar se está logado
function isLogado() {
    return isset($_SESSION['usuario_logado']);
}

// Obter usuário logado
function getUsuarioLogado() {
    return $_SESSION['usuario_logado'] ?? null;
}

// Redirecionar se não estiver logado
function requireLogin() {
    if (!isLogado()) {
        // !!!! MUDANÇA IMPORTANTE AQUI !!!!
        // Redireciona para "login.php" (tela de login) em vez de "index.php" (landing page)
        header('Location: login.php');
        exit;
    }
}
?>