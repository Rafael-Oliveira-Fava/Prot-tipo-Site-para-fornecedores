<?php
require_once 'config.php';
require_once 'auth.php';
requireLogin();

$usuario = getUsuarioLogado();
$pagina = $_GET['p'] ?? 'dashboard';

// Buscar estatísticas
$db = getDB();
$totalProdutos = $db->query("SELECT COUNT(*) FROM produtos")->fetchColumn();
$totalUnidades = $db->query("SELECT SUM(quantidade) FROM produtos")->fetchColumn();
$totalFornecedores = $db->query("SELECT COUNT(*) FROM fornecedores")->fetchColumn();
$totalMovimentacoes = $db->query("SELECT COUNT(*) FROM historico_produtos")->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FarmaAura - Sistema</title>
    <link rel="stylesheet" href="style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700;800&display=swap" rel="stylesheet">
</head>

<body>
    <div id="app" class="tela">
        <header class="app-header">
            <div class="logo">
                <img src="Captura_de_tela_2025-10-13_123538-removebg-preview.png" alt="Logo FarmaAura" class="logo-imagem">
                <div>
                    <h1 class="tituloLogo">FarmaAura</h1>
                    <p>Olá, <?php echo e($usuario['nome']); ?></p>
                </div>
            </div>

            <a href="logout.php" class="btn btn-danger">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" />
                    <polyline points="16 17 21 12 16 7" />
                    <line x1="21" y1="12" x2="9" y2="12" />
                </svg>
                Sair
            </a>
        </header>

        <nav class="app-nav">
            <a href="?p=dashboard" class="nav-btn <?php echo $pagina === 'dashboard' ? 'active' : ''; ?>">Dashboard</a>
            <a href="?p=fornecedores" class="nav-btn <?php echo $pagina === 'fornecedores' ? 'active' : ''; ?>">Fornecedores</a>
            <a href="?p=produtos" class="nav-btn <?php echo $pagina === 'produtos' ? 'active' : ''; ?>">Produtos</a>
            <a href="?p=movimentar" class="nav-btn <?php echo $pagina === 'movimentar' ? 'active' : ''; ?>">Movimentar Estoque</a>
            <a href="?p=historico" class="nav-btn <?php echo $pagina === 'historico' ? 'active' : ''; ?>">Histórico de Produtos</a>
            <a href="?p=fale-conosco" class="nav-btn <?php echo $pagina === 'fale-conosco' ? 'active' : ''; ?>">Fale Conosco</a>
        </nav>

        <main class="app-content">
            <?php
            switch ($pagina) {
                case 'movimentar':
                    include 'pages/movimentar.php';
                    break;
                case 'fornecedores':
                    include 'pages/fornecedores.php';
                    break;
                case 'produtos':
                    include 'pages/produtos.php';
                    break;
                case 'historico':
                    include 'pages/historico.php';
                    break;
                case 'fale-conosco':
                    include 'pages/fale-conosco.php';
                    break;
                default:
                    // Verifica se o home.php existe
                    if (file_exists('pages/home.php')) {
                        include 'pages/home.php';
                    } else {
                        // Se 'pages/home.php' não existir, carrega 'home.php' da raiz
                        include 'home.php';
                    }
            }
            ?>
        </main>

        <footer class="app-footer">
            <div class="footer-container">
                <div class="footer-column">
                    <h4>Institucional</h4>
                    <ul>
                        <li><a href="#">Sobre a FarmaAura</a></li>
                        <li><a href="#">Nossa Equipe</a></li>
                        <li><a href="#">Carreiras</a></li>
                        <li><a href="#">Termos de Uso</a></li>
                    </ul>
                </div>
                <div class="footer-column">
                    <h4>Atendimento</h4>
                    <p><strong>Telefone:</strong> (11) 4002-8922</p>
                    <p><strong>E-mail:</strong> suporte@farmaaura.com.br</p>
                    <p>Segunda a Sexta, das 8h às 18h</p>
                </div>
                <div class="footer-column">
                    <h4>Redes Sociais</h4>
                    <div class="social-icons">
                        <a href="#" aria-label="Facebook"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M18 2h-3a5 5 0 0 0-5 5v3H7v4h3v8h4v-8h3l1-4h-4V7a1 1 0 0 1 1-1h3z" />
                            </svg></a>
                        <a href="#" aria-label="Instagram"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="2" y="2" width="20" height="20" rx="5" ry="5" />
                                <path d="M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z" />
                                <line x1="17.5" y1="6.5" x2="17.51" y2="6.5" />
                            </svg></a>
                        <a href="#" aria-label="LinkedIn"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M16 8a6 6 0 0 1 6 6v7h-4v-7a2 2 0 0 0-2-2 2 2 0 0 0-2 2v7h-4v-7a6 6 0 0 1 6-6z" />
                                <rect x="2" y="9" width="4" height="12" />
                                <circle cx="4" cy="4" r="2" />
                            </svg></a>
                    </div>
                </div>
            </div>
            <div class="footer-bottom">
                <p>© 2025 FarmaAura Ltda. Todos os direitos reservados.</p>
            </div>
        </footer>
    </div>
</body>

</html>