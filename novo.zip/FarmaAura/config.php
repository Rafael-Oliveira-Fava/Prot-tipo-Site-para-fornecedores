<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
// Configurações do banco de dados
define('DB_HOST', 'localhost');
define('DB_NAME', 'farmaaura');
define('DB_USER', 'root');
define('DB_PASS', 'Senai@118');
define('DB_CHARSET', 'utf8mb4');

// Função para conectar ao banco
function getDB() {
    static $pdo = null;
    
    if ($pdo === null) {
        try {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=" . DB_CHARSET;
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
            ];
            $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die("Erro de conexão com o banco de dados: " . $e->getMessage());
        }
    }
    
    return $pdo;
}

// Função para escapar HTML
function e($string) {
    return htmlspecialchars($string ?? '', ENT_QUOTES, 'UTF-8');
}

// Função para formatar moeda
function formatMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

// Função para formatar data
function formatData($data) {
    return date('d/m/Y H:i:s', strtotime($data));
}

// Iniciar sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>